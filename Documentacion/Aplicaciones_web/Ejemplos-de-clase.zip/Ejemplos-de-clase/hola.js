window.alert('Saludo desde el fichero de script!')
