function test(){
    if("geolocation" in navigator){
    console.log("Location is available");
    } else {
    console.log("Location is not available");
    }  
}
