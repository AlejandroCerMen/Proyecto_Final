const elemento = document.getElementById("elemento");
const destino = document.getElementById("destino");


// PASO 0: Habilitar el arrastre desde JavaScript
// El elemento que queramos arrastrar debe ser draggable
--

// PASO 1: Al comenzar a arrastrar - Al clicar sobre la carta (imagen del gato en este caso) queremos guardarnos la información de ese elemento para arrastarlo.
elemento.addEventListener("dragstart", function(evento) {
    console.log("EVENTO: dragstart → comienza el arrastre");
    // Lo primero que hemos de hacer es "almacenar" el id de la carta que queremos mover dentro del atributo DataTransfer del objeto DragEvent para que "viaje" con nuestra carta.
    --
});

// PASO 2: Mientras el elemento está sobre el destino
destino.addEventListener("dragover", function(evento) {
    console.log("EVENTO: dragover → el elemento está sobre el destino");
    // Para que podamos reaccionar a este evento a través de nuestro código, evitando la reacción por defecto del navegador...
    --
    // Para darle un toque visual, podemos cambiar el color de fondo del elemento destino (en vuestro caso, el tapete del solitario)
    --    
});

// Otra reacción - No es necesaria para la práctica... podríamos establecer que el color del tapete destino cambiara cuando el ratón con la carta arrastrada salga de ese área...
destino.addEventListener("dragleave", function(evento) {
    console.log("EVENTO: dragleave → salimos del destino");
    // Podemos volver a pasar el fondo a color blanco
    --
});

// PASO 3: Cuando se suelta el elemento -> Cuando queremos que se mueva la carta
destino.addEventListener("drop", function(evento) {
    console.log("EVENTO: drop → soltamos el elemento");
    // Lo primero que debemos realizar es indicar que queremos programar la respuesta a este evento, evitando que se dispare la reacción por defecto
    --
    // Cuando sucede el drop, queremos recuperar la carta que estábamos arrastrando. Esta información la tenemos en el DataTransfer, así que la recuperamos:
    --
    console.log(--
    // Como ese elemento ya existe (es un objeto HTML del DOM), lo cogemos:
    --
    // Queremos que no esté "colgando" en el DOM, sino "añadirlo" al tapete. Esto se hace con appendChild
    --
    // Similar a lo que hemos hecho con "dragleave", queremos que el fondo vuelva a ser blanco tras arrastrar la carta apropiadamente.
    --
});

// Evento extra: termina el arrastre, se haya soltado correctamente o no
elemento.addEventListener("dragend", function() {
    console.log("EVENTO: dragend → terminó el arrastre");
});
