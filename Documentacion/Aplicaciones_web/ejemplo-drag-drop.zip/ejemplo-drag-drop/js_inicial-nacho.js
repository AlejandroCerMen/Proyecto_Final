const elemento = document.getElementById("elemento");
const destino = document.getElementById("destino");


// PASO 0: Habilitar el arrastre desde JavaScript
// El elemento que queramos arrastrar debe ser draggable
elemento.draggable=true;

// PASO 1: Al comenzar a arrastrar - Al clicar sobre la carta (imagen del gato en este caso) queremos guardarnos la información de ese elemento para arrastarlo.
elemento.addEventListener("dragstart", function(evento) {
    console.log("EVENTO: dragstart → comienza el arrastre");
    // Lo primero que hemos de hacer es "almacenar" el id de la carta que queremos mover dentro del atributo DataTransfer del objeto DragEvent para que "viaje" con nuestra carta.
    evento.dataTransfer.setData("text/plain",elemento.id); 
});

// PASO 2: Mientras el elemento está sobre el destino
destino.addEventListener("dragover", function(evento) {
    console.log("EVENTO: dragover → el elemento está sobre el destino");
    // Para que podamos reaccionar a este evento a través de nuestro código, evitando la reacción por defecto del navegador...
    evento.preventDefault();
    // Para darle un toque visual, podemos cambiar el color de fondo del elemento destino (en vuestro caso, el tapete del solitario)
    destino.style.backgroundColor = "lightyellow";    
});

// Otra reacción - No es necesaria para la práctica... podríamos establecer que el color del tapete destino cambiara cuando el ratón con la carta arrastrada salga de ese área...
destino.addEventListener("dragleave", function(evento) {
    console.log("EVENTO: dragleave → salimos del destino");
    // Podemos volver a pasar el fondo a color blanco
    destino.style.backgroundColor = "white";
});

// PASO 3: Cuando se suelta el elemento -> Cuando queremos que se mueva la carta
destino.addEventListener("drop", function(evento) {
    console.log("EVENTO: drop → soltamos el elemento");
    // Lo primero que debemos realizar es indicar que queremos programar la respuesta a este evento, evitando que se dispare la reacción por defecto
    evento.preventDefault();
    // Cuando sucede el drop, queremos recuperar la carta que estábamos arrastrando. Esta información la tenemos en el DataTransfer, así que la recuperamos:
    let id_carta = evento.dataTransfer.getData("text/plain");
    console.log("Id del elemento",id_carta);
    // Como ese elemento ya existe (es un objeto HTML del DOM), lo cogemos:
    carta = document.getElementById(id_carta);
    // Queremos que no esté "colgando" en el DOM, sino "añadirlo" al tapete. Esto se hace con appendChild
    destino.appendChild(carta);
    // Similar a lo que hemos hecho con "dragleave", queremos que el fondo vuelva a ser blanco tras arrastrar la carta apropiadamente.
    destino.style.backgroundColor = "white";
});

// Evento extra: termina el arrastre, se haya soltado correctamente o no
elemento.addEventListener("dragend", function() {
    console.log("EVENTO: dragend → terminó el arrastre");
});
