const elemento = document.getElementById("elemento");
const destino = document.getElementById("destino");
const estado = document.getElementById("estado");

console.log("Práctica Drag & Drop iniciada");

// PASO 0: Habilitar el arrastre desde JavaScript
elemento.draggable = true;
console.log("ACCIÓN: habilitamos draggable desde JavaScript");

// PASO 1: Al comenzar a arrastrar
elemento.addEventListener("dragstart", function(evento) {
    console.log("EVENTO: dragstart → comienza el arrastre");
    evento.dataTransfer.setData("text/plain", elemento.id);
    console.log("ACCIÓN: guardamos el ID:", elemento.id);
});

// PASO 2: Mientras el elemento está sobre el destino
destino.addEventListener("dragover", function(evento) {
    console.log("EVENTO: dragover → el elemento está sobre el destino");
    evento.preventDefault();
    destino.style.backgroundColor = "lightgreen";
    estado.textContent = "Estás sobre el destino";
    console.log("ACCIÓN: permitimos drop y coloreamos el destino");
});

// PASO 3: Cuando el elemento abandona el destino
destino.addEventListener("dragleave", function(evento) {
    console.log("EVENTO: dragleave → salimos del destino");
    destino.style.backgroundColor = "white";
    console.log("ACCIÓN: restauramos el fondo blanco");
});

// PASO 4: Cuando se suelta el elemento
destino.addEventListener("drop", function(evento) {
    console.log("EVENTO: drop → soltamos el elemento");
    evento.preventDefault();
    const id = evento.dataTransfer.getData("text/plain");
    console.log("ACCIÓN: recuperamos el ID:", id);
    const elementoArrastrado = document.getElementById(id);
    if (!elementoArrastrado) return;
    destino.appendChild(elementoArrastrado);
    destino.style.backgroundColor = "white";
    estado.textContent = "Elemento soltado correctamente";
    console.log("ACCIÓN: movemos el elemento al destino");
});

// Evento extra: termina el arrastre, se haya soltado correctamente o no
elemento.addEventListener("dragend", function() {
    console.log("EVENTO: dragend → terminó el arrastre");
});
