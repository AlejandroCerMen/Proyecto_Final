const x = "ALOHA";
let y = 100;
document.writeln(
  "Escrito en el script externo. Variable x = " + x + " e y = " + y
);

window.alert("Fin del script!");
