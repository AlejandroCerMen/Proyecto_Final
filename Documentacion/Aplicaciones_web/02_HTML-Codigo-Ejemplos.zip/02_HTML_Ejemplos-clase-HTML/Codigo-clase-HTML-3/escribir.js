document.write("Parte escrita en el script EXTERNO");
